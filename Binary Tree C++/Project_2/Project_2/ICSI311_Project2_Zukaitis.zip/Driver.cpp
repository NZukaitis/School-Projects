#include "Test.h"
int main()
{
	Test *t = new Test();
	t->startTest();
}

